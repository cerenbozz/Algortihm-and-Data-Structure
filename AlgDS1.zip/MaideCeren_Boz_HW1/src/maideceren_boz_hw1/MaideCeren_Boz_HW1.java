/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package maideceren_boz_hw1;

/**
 *
 * @author ceren
 */
import java.util.Random;
import java.util.Arrays;

public class MaideCeren_Boz_HW1 {
    private static long count = 0;

    private static int[] sizes = {100, 300, 500, 700, 800, 900, 1000, 2000, 3000, 4000, 5000, 5500, 6000, 7000, 10000};

    // Linear search O(N)
    public static int linearSearch(int[] data, int target) {
        long count=0;
        for (int i = 0; i < data.length; i++) {
            count++;
            if (target == data[i]){
                System.out.println("\nLinear Search Count: " + count);
                return i;
            }
        }
        System.out.println("\nLinear Search Count: " + count);
        return -1;
    }


    // binary search O(logn)
    public static int binarySearch(int[] data, int target) {
        int count = 0;
        int left = 0;
        int right = data.length - 1;
        while (left <= right) {
            int mid = (left + right) / 2;
            count++;
            if (target == data[mid]) {
                System.out.println("\nBinary Search Count: " + count);
                return mid;
            } else if (target < data[mid]) {
                right = mid - 1;
            } else {
                left = mid + 1;


            }
        }
        System.out.println("\nBinary Search Count: " + count);
        return -1;
    }

    // bubble sort O(n^2)
    public static int[] bubbleSort(int[] data) {
        int count = 0;
        for (int i = data.length; i > 1; i--) {
            for (int j = 0; j < i - 1; j++) {
                count++;
                if (data[j] > data[j + 1]) {
                    int temp = data[j];
                    data[j] = data[j + 1];
                    data[j + 1] = temp;

                }
            }
        }
        System.out.println("\nBubble Sort Count: " + count);
        return data;
    }

    // O(N^3)
    public static int[] N3(int[] data) {
        count = 0;
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data.length; j++) {
                for (int k = 0; k < data.length - 1; k++) {
                    count++;
                }
            }
        }
        System.out.println("\nN3 Count: " + count);
        return data;
    }

    private static int[] generateRandomArray(int size) {
        int[] array = new int[size];
        Random rand = new Random();

        for (int i = 0; i < size; i++) {
            array[i] = rand.nextInt(10000); 
        }

        return array;
    }

    public static void main(String[] args) {
        for (int size : sizes) {
            int[] dataSet = generateRandomArray(size);
            System.out.println("Data Size: " + size);

            // Measure bubble sort time 
            long startTime = System.nanoTime();
            bubbleSort(dataSet.clone());
            long endTime = System.nanoTime();
            long elapsedNanoseconds = endTime - startTime;
            long bubbleSortTimeMicros = elapsedNanoseconds / 1000;
            System.out.println("Bubble Sort Time: " + bubbleSortTimeMicros + " microseconds");
            long bubbleSortCount = count;


            // Measure linear search time
            startTime = System.nanoTime();
            linearSearch(dataSet.clone(), 10001);
            endTime = System.nanoTime();
            elapsedNanoseconds = endTime - startTime;
            long linearSearchTimeMicros = elapsedNanoseconds / 1000;
            System.out.println("Linear Search Time: " + linearSearchTimeMicros + " microseconds");
            long linearSearchCount = count;

            // Measure binary search time
            Arrays.sort(dataSet); // Binary search requires sorting
            startTime = System.nanoTime();
            binarySearch(dataSet, 1);
            endTime = System.nanoTime();
            elapsedNanoseconds = endTime - startTime;
            long binarySearchTimeMicros = elapsedNanoseconds / 1000;
            System.out.println("Binary Search Time: " + binarySearchTimeMicros + " microseconds");
            long binarySearchCount = count;


            // Measure O(N^3) time 
            startTime = System.nanoTime();
            N3(dataSet.clone());
            endTime = System.nanoTime();
            elapsedNanoseconds = endTime - startTime;
            long N3TimeMicros = elapsedNanoseconds / 1000;
            System.out.println("N3 Time: " + N3TimeMicros + " microseconds");
            long N3Count = count;

            System.out.println();
        }
    }

}
