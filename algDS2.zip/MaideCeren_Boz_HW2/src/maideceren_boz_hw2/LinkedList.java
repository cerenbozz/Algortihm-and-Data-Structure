/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maideceren_boz_hw2;

/**
 *
 * @author ceren
 */
import javax.lang.model.element.Element;
import javax.lang.model.element.Name;

public class LinkedList implements HW2Interface {
private DLNode head;
    public LinkedList() {

        head = null;
    }
    public int size=0;
    @Override
    public void Insert(int newElement, int pos) throws Exception {
        if (pos<0 || pos>size) {
            throw LinkedListException();
        }
        DLNode newNode;
        newNode = new DLNode();
        newNode.Element =newElement;
        if (pos==0) {
            newNode.right = head;
            if(head != null){
                head.left =newNode;
            }
            head = newNode;
            size++;
        } else {
            DLNode temp = head;
            for (int i =1; i<pos; i++){
                temp =temp.right;
            }
            newNode.right=temp.right;
            newNode.left=temp;
            if (temp.right != null){
                temp.right.left=newNode;
                temp.right=newNode;
            }
            newNode.left=temp;
            temp.right= newNode;

            }
            size++;
        }

    @Override
    public int Delete(int pos) throws Exception {
        if (pos <0 || head==null){
            throw LinkedListException();
        }
        int deletedElement = 0;

        if (pos==0){
            deletedElement = head.Element;
            head = head.right;
            if(head!=null){
                head.left=null;
            }
            size--;
            return deletedElement;
        }else if(pos<size) {
            DLNode temp = head;
            int index =0;
            while(index<pos-1 && temp != null){
                temp=temp.right;
                index++;
            }

            if (temp==null) {
                throw LinkedListException();
            }
            deletedElement= temp.Element;
            if (temp.left!=null){
                temp.left.right=temp.right;
            }
            if (temp.right!=null){
                temp.right.left=temp.left;
            }
        }

        return deletedElement;
    }

    @Override
    public void ReverseLink() {
        DLNode dummy =head;
        DLNode temp =null;

        while (dummy!=null){
            temp = dummy.left;
            dummy.left= dummy.right;
            dummy.right=temp;
            dummy=dummy.left;
        }
        if (temp !=null){
            head =temp.left;
        }

    }

    @Override
    public void SquashL() throws Exception {
        DLNode current = head;
        //DLNode originalNext;
        int index = 0;
        int count = 1;
        int value;
    while (current != null && current.right != null) {
        value = current.Element;

        while (value == current.right.Element) {
            count++;
            DLNode temp = head;
            int inx = 0;

            while (inx < index) {
                temp = temp.right;
                inx++;
            }
            temp.right = temp.right.right;
            temp.right.left = temp;
            size--;
        }
        DLNode newNode = new DLNode();
        newNode.Element = count;
        DLNode temp = head;
        int inx = 0;

        while (inx < index) {
            temp = temp.right;
            inx++;
        }
        newNode.right = temp.right;
        newNode.left = temp;
        newNode.right.left = newNode;
        newNode.left.right = newNode;
        size++;
        count = 1;
        current = current.right.right;
        index += 2;
    }
    DLNode newNode = new DLNode();
    newNode.Element = count;
    DLNode temp = head;

    while (temp.right != null) {
        temp = temp.right;
    }
    newNode.left = temp;
    temp.right = newNode;
    size++;
}


    @Override
    public void OplashL() {
        DLNode current = head;
        int index = 0;

        while (current != null && current.right != null) {
            int value = current.Element;
            int count = current.right.Element;
            if (current.right.right == null) {
                current.right = null;
                size--;
            } else {
                current.right = current.right.right;
                current.right.left = current;
                size--;
            }

            while (count != 1) {
                DLNode newNode = new DLNode();
                newNode.Element = value;
                newNode.right = current.right;
                newNode.left = current;
                if (current.right != null) {
                    current.right.left = newNode;
                }
                current.right = newNode;
                size++;
                count--;
                current = current.right;
                index++;
            }
            current = current.right;
            index++;
        }
    }

    @Override
    public void Output() {
        System.out.println("The Elements in the list are:" + toString());

    }

    @Override
    public void ROutput() {
        ReverseLink();
        System.out.println("The Reverse Elements in the list are:" + toString());
        ReverseLink();

    }
    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        DLNode current = head;

        while (current != null) {
            result.append(current.Element).append(" ");
            current = current.right;
        }

        if (result.length() > 0) {
            return result.toString().trim();
        } else {
            return result.toString();
        }
    }

    @Override
    public Exception LinkedListException() {
        return new Exception("Not supported yet.");
    }
}

