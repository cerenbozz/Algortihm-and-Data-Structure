/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maideceren_boz_hw2;

/**
 *
 * @author ceren
 */
public class DLNode {
    public int Element;
    public DLNode left;
    public DLNode right;
}