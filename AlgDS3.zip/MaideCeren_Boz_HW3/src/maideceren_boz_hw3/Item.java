/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maideceren_boz_hw3;

/**
 *
 * @author ceren
 */
public class Item {
    String ItemName;
    String Date;
    float Price;
    Item Link;

    // Parametre almayan bir constructor ekleyin
    public Item() {
    }

    // Parametre alan bir constructor ekleyin
    public Item(String ItemName, String Date, float Price) {
        this.ItemName = ItemName;
        this.Date = Date;
        this.Price = Price;
    }

    public void setItemName(String ItemName) {
        this.ItemName = ItemName;
    }

    public String getItemName() {
        return ItemName;
    }

    public void setLink(Item Link) {
        this.Link = Link;
    }

    public Item getLink() {
        return Link;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public String getDate() {
        return Date;
    }

    public void setPrice(float Price) {
        this.Price = Price;
    }

    public float getPrice() {
        return Price;
    }
}