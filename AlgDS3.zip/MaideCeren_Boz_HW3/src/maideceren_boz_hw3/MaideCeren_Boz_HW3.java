/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package maideceren_boz_hw3;

/**
 *
 * @author ceren
 */
 

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;



public class MaideCeren_Boz_HW3 implements DB_Interface {

    private int size = 0;
    private Customer[] myArray = new Customer[100];

    public void addCustomer(Customer newCustomer) { // Adds a new customer into the database
        myArray[size++]=newCustomer;
    }

    public void listItems(int ID) { // It displays on the screen every item for which the customer has ID
        Customer myCustomer = search_Customer(ID);
        if (myCustomer != null) {
            System.out.println(myCustomer.getName() + " " + myCustomer.getSurname() + " " + myCustomer.getID() + " Item List :");
            Item temp = myCustomer.getLink();
            while (temp != null) {
                System.out.println(temp.getItemName() + " " + temp.getDate() + " " + temp.getPrice());
                temp = temp.getLink();
            }
        } else {
            System.err.println("error: customer not found - ID: " + ID);
        }
    }

    public Customer getNewCustomer(String Name, String Surname, int ID) { // Constructs and returns a new Customer object.
        Customer myCustomer = new Customer();
        myCustomer.setName(Name);
        myCustomer.setID(ID);
        myCustomer.setSurname(Surname);
        return myCustomer;
    }

    public void addNewItem(Integer ID, String ItemName, String Date, Float Price) { // Inserts a new record with a certain customer ID into the database
        try {
            if (ID == null || ItemName == null || Date == null) {
                System.err.println("error: not enough knowlage - ID: " + ID + ", ItemName: " + ItemName + ", Date: " + Date + ", Price: " + Price);
                return;
            }

            Customer myCustomer = search_Customer(ID);
            if (myCustomer == null) {
                addCustomer(getNewCustomer("customer", "no", ID));
                myCustomer = search_Customer(ID);
            }

            Item myItem = new Item(ItemName, Date, Price);
            myItem.setLink(myCustomer.getLink());
            myCustomer.setLink(myItem);

        } catch (NumberFormatException e) {
            System.err.println("error: invalid number format - ID: " + ID + ", ItemName: " + ItemName + ", Date: " + Date + ", Price: " + Price);
            e.printStackTrace();
        }
    }

    public Float getTotalTradeofCustomer(int ID) { // Determines the total trade amount associated with a certain client ID
        Customer myCustomer = search_Customer(ID);
        if (myCustomer != null) {
            Item temp = myCustomer.getLink();
            Float trade = 0f;
            while (temp != null) {
                trade += temp.getPrice();
                temp = temp.getLink();
            }
            return trade;
        } else {
            return getTotalTrade();
        }
    }

    public Float getTotalTrade() { // Determines the total trade amount for each and every database customer
        Float totalTrade = 0f;
        int index = 0;
        while (index < size) {
            totalTrade += getTotalTradeofCustomer(myArray[index++].getID());
        }
        return totalTrade;
    }

    public void readFromFile(String path) { // Reads customer and item data from a file and populates the database
        try {
            File file = new File(path);
            Scanner sc = new Scanner(file);
            Customer currentCustomer = null;

            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();

                String[] parts = line.split("\\s+");

                if (parts.length == 3) {
                    try {
                        int customerID = Integer.parseInt(parts[parts.length - 1]);
                        String customerName = line.replaceFirst(Integer.toString(customerID), "").trim();
                        currentCustomer = getNewCustomer(customerName, "", customerID);
                        addCustomer(currentCustomer);
                    } catch (NumberFormatException e) {
                        System.err.println("error: invalid customer ID format - row: " + line);
                    }
                } else if (parts.length == 4) {
                    try {
                        int customerID = Integer.parseInt(parts[0]);
                        addNewItem(customerID, parts[1], parts[2], Float.parseFloat(parts[3]));
                    } catch (NumberFormatException e) {
                        System.err.println("error: invalid number format - row: " + line);
                    }
                } else {
                    System.err.println("error: invalid row format - row: " + line);
                }
            }
            System.out.println("The content of the file has been read");
        } catch (FileNotFoundException e) {
            System.err.println("error: file not found - " + path);
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("unknown error occurred:");
            e.printStackTrace();
        }
    }


    public Customer search_Customer(int ID) { //returns the customer object of ID
        Customer myCustomer = null;
        int i = 0;
        while (i < size) {
            if (myArray[i] != null && myArray[i].getID() == ID) {
                myCustomer = myArray[i];
                break;
            }
            i++;
        }
        return myCustomer;
    }

    public static void main(String[] args) {
        MaideCeren_Boz_HW3 MyDataBase = new MaideCeren_Boz_HW3();
        Customer DummyCustomer = new Customer();
        MyDataBase.readFromFile("C:\\Yeni Klasör\\MyData.txt");
        Float exps = MyDataBase.getTotalTradeofCustomer (13456);
        System.out.println(MyDataBase.search_Customer (13456) + " Total Expense: "+ exps ); //+ exps
        System.out.println("The Total Trade: " + MyDataBase.getTotalTrade());
        MyDataBase.listItems(13456);
        Customer newc = MyDataBase.getNewCustomer("Ali", "Veli", 4950);
        MyDataBase.addCustomer(newc);
        MyDataBase.addNewItem(4950, "Karburator", "Monday", 145.8f);
        MyDataBase.addNewItem(4950, "Laptop", "Tuesday", 2340f);
        System.out.println("The Total Trade: " + MyDataBase.getTotalTrade());
        MyDataBase.listItems(4950);

    }
}
