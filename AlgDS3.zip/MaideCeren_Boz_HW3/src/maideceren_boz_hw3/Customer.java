/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maideceren_boz_hw3;

public class Customer {
    private String Name;
    private String Surname;
    private int ID;
    private Item Link;

    public Customer(String name, String surname, int id) {
        this.Name = name;
        this.Surname = surname;
        this.ID = id;
    }

    // Parametre almayan constructor ekledik
    public Customer() {
        // İhtiyaca bağlı olarak burada başka başlangıç işlemleri yapılabilir.
    }

    @Override
    public String toString() {
        return "Name " + Name + " Surname " + Surname + " ID " + ID;
    }

    public int getID() {
        return ID;
    }

    public void setID(int id) {
        this.ID = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public Item getLink() {
        return Link;
    }

    public void setLink(Item link) {
        this.Link = link;
    }

    public String getSurname() {
        return Surname;
    }

    public void setSurname(String surname) {
        this.Surname = surname;
    }
}
