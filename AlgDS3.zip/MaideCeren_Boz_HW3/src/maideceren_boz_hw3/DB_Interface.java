/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package maideceren_boz_hw3;

/**
 *
 * @author ceren
 */
import java.io.FileNotFoundException;

public interface DB_Interface {
    void addCustomer(Customer newCustomer);
    void listItems(int ID);
    Customer getNewCustomer(String Name, String Surname, int ID);
    void addNewItem(Integer ID, String ItemName, String Date, Float Price);
    Float getTotalTradeofCustomer(int ID);
    Float getTotalTrade();
    void readFromFile(String path) throws FileNotFoundException, InterruptedException, Exception;
    Customer search_Customer(int ID);
}
