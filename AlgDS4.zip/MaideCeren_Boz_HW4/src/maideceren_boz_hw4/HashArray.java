/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maideceren_boz_hw4;

/**
 *
 * @author ceren
 */
public class HashArray {
    HashN node;
    int maxFrequency;

    public HashArray(HashN node) {
        this.node = node;
        this.maxFrequency = 0;
    }

}
